
import images.omero as omr
import images.climb as climb
import images.jaxlims as jxl
import collections
import logging
import os
import shutil
import socket
import sys
from collections import defaultdict
from errno import errorcode
from getpass import getpass
from logging.handlers import RotatingFileHandler
from typing import Any
import mysql.connector
import paramiko
import requests
from requests import exceptions
from urllib3.connection import HTTPConnection

"""Setup logger"""

logger = logging.getLogger(__name__)
FORMAT = "[%(asctime)s->%(filename)s->%(funcName)s():%(lineno)s]%(levelname)s: %(message)s"
logging.basicConfig(format=FORMAT, filemode="w", level=logging.DEBUG, force=True)
logging_dest = os.path.join(os.getcwd(), "Output")
logging_filename = os.path.join(os.getcwd(), "Output", "App.log")
try:
    os.mkdir(logging_dest)

except OSError as e:
    print(e)

handler = logging.handlers.RotatingFileHandler(logging_filename, maxBytes=10000000000000, backupCount=10)
handler.setFormatter(logging.Formatter(FORMAT))
logger.addHandler(handler)


def main():
    """Set a higher timeout tolerance"""
    HTTPConnection.default_socket_options = (HTTPConnection.default_socket_options + [
        (socket.SOL_SOCKET, socket.SO_SNDBUF, 1000000),
        (socket.SOL_SOCKET, socket.SO_RCVBUF, 1000000)
    ])

    print("Where do you want to download your images from?\n")
    downloadSource = input("Enter images source:")

    if downloadSource == "Omero":

        targetPath = os.path.join("/Users/chent/Desktop/KOMP_Images", "Omeros")
        logger.debug(f"Target path is {targetPath}")
        try:
            os.mkdir(targetPath)

        except FileExistsError as e:
            logger.warning("File/folder exists")

        server = "rslims.jax.org"
        username = "dba"
        password = "rsdba"
        database = "rslims"

        conn = omr.db_init(server=server, username=username, password=password, database=database)

        sql = """SELECT ProcedureStatus, 
                        ProcedureDefinition, 
                        ProcedureDefinition.ExternalID AS ExternalID, 
                        _ProcedureInstance_key AS TestCode, 
                        OutputValue, DateDue,
                        OrganismID,
                        DateBirth,
                        StockNumber
                    FROM
                        Organism
                            INNER JOIN
                        ProcedureInstanceOrganism USING (_Organism_key)
                            INNER JOIN
                        ProcedureInstance USING (_ProcedureInstance_key)
                            INNER JOIN
                        OutputInstanceSet USING (_ProcedureInstance_key)
                            INNER JOIN
                        Outputinstance USING (_outputInstanceSet_key)
                            INNER JOIN
                        Output USING (_Output_key)
                            INNER JOIN
                        ProcedureDefinitionVersion USING (_ProcedureDefinitionVersion_key)
                            INNER JOIN
                        ProcedureDefinition USING (_ProcedureDefinition_key)
                            INNER JOIN
                        Line USING (_Line_key)
                            INNER JOIN
                        OrganismStudy USING (_Organism_key)
                            INNER JOIN
                        cv_ProcedureStatus USING (_ProcedureStatus_key)
                    WHERE
                        Output._DataType_key = 7   -- File type
                            AND OutputValue LIKE '%omeroweb%' 
                            AND CHAR_LENGTH(OutputValue) > 0
                            AND _LevelTwoReviewAction_key = 13
                            AND _Study_key = 27
                            AND Output.ExternalID IS NOT NULL"""
        
        print("How would you like to select thhe images?")
        query_filters = {"DateDue": input("Date:"),
                         "ProcedureStatus": input("Status:"),
                         "OrganismID": input("Animal ID:"),
                         "Output.ExternalID": input("IMPC Code:")}

        """Form the sql queries based on user input"""
        for key, val in query_filters.items():
            if not query_filters[key]:
                continue
            if key == "DateDue":
                val = val.replace("-", "")
                sql = sql + f" AND DateDue >= {val}"
            else:
                filter_clause = f" AND {key} LIKE '%{val}%'"
                sql = sql + filter_clause

        sql = sql + ";"
        #print(sql)
        print()
        print("Please enter your username and password to log in")
        username = input("Username: ")
        password = getpass("Password: ")
        omr.download_from_omero(username=username, password=password, download_to=targetPath, conn=conn, sql=sql)
        conn.close()

    '''Download images in JaxLims'''
    if downloadSource == "JaxLims":
        #print("Where are the file locations being stored? ")
        print("How would you like to select?")
        query_filters = {"DateDue": input("Date:"),
                         "OrganismID": input("Animal ID:"),
                         "ExternalID": input("Parameter Code:")}

        server = "rslims.jax.org"
        username = "dba"
        password = "rsdba"
        database = "rslims"

        conn = jxl.db_init(server=server, username=username, password=password, database=database)
        sql = """SELECT ProcedureStatus, 
                                           ProcedureDefinition, 
                                           ProcedureDefinition.ExternalID AS ExternalID, 
                                           _ProcedureInstance_key AS TestCode, 
                                           OutputValue, DateDue,
                                           OrganismID,
                                           DateBirth,
                                           StockNumber
                                       FROM
                                           Organism
                                               INNER JOIN
                                           ProcedureInstanceOrganism USING (_Organism_key)
                                               INNER JOIN
                                           ProcedureInstance USING (_ProcedureInstance_key)
                                               INNER JOIN
                                           OutputInstanceSet USING (_ProcedureInstance_key)
                                               INNER JOIN
                                           Outputinstance USING (_outputInstanceSet_key)
                                               INNER JOIN
                                           Output USING (_Output_key)
                                               INNER JOIN
                                           ProcedureDefinitionVersion USING (_ProcedureDefinitionVersion_key)
                                               INNER JOIN
                                           ProcedureDefinition USING (_ProcedureDefinition_key)
                                               INNER JOIN
                                           Line USING (_Line_key)
                                               INNER JOIN
                                           OrganismStudy USING (_Organism_key)
                                               INNER JOIN
                                           cv_ProcedureStatus USING (_ProcedureStatus_key)
                                       WHERE
                                           Output._DataType_key = 7   -- File type
                                               AND OutputValue LIKE '%phenotype%' 
                                               AND CHAR_LENGTH(OutputValue) > 0
                                               AND _LevelTwoReviewAction_key = 13
                                               AND _Study_key = 27
                                               AND Output.ExternalID IS NOT NULL"""

        """Form the sql queries based on user input"""
        for key, val in query_filters.items():
            if not query_filters[key]:
                continue
            if key == "DateDue":
                val = val.replace("-", "")
                sql = sql + f" AND DateDue >= {val}"
            else:
                filter_clause = f" AND {key} LIKE '%{val}%'"
                sql = sql + filter_clause

        sql = sql + ";"

        # List stores additional condition on sql query
        targetPath = os.path.join("/Users/chent/Desktop/KOMP_Images", "JaxLims")
        fileLocationMap = jxl.buildFileMap(conn=conn, sql=sql, target=targetPath)
        # srcPath = "//bht2stor.jax.org/" #If you are on windows
        srcPath = "/Volumes/"  # If you are on mac/linux
        jxl.download_from_drive(fileLocationMap, source=srcPath, target=targetPath)

    if downloadSource == "Climb":
        srcPath = "/Volumes/"
        targetPath = "/Users/chent/Desktop/KOMP_Images"
        # srcPath = "//bht2stor.jax.org/" #If you are on windows

        username = input("Username: ")
        password = input("Password: ")
        token = climb.getTokens(username=username, password=password)
        json_objects = climb.getFileInfo(username=username, password=password, token=token, outputKey=658)
        fileLocationMap = climb.buildFileMap(json_objects)
        climb.download_from_drive(fileLocationMap=fileLocationMap, source=srcPath, target=targetPath)

    if downloadSource == "PFS" or "Core":

        # Connect to server of PFS, then extract information of images
        pass

    else:
        raise ValueError("Invalid file source detected!")


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()
