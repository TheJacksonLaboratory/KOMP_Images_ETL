# Description

To use the application,  `cd` to the project directory, use the command `python App.py`, then input the information to start downloading images . For now, more decoration needs to be made for this project. 
